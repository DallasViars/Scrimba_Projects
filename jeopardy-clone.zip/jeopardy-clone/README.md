# Jeopardy Clone

A Pen created on CodePen.io. Original URL: [https://codepen.io/dallasviars/pen/WNzoXep](https://codepen.io/dallasviars/pen/WNzoXep).

One of Scrimba's lessons teaching about combining CSS Grid and Fetch was to create a Jeopardy board using an API to fetch categories for the headers and render the board using Javascript. I enjoyed this so much that I was inspired to make a functional Jeopardy board.